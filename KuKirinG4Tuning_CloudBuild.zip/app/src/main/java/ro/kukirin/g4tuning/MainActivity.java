package ro.kukirin.g4tuning;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int accent = Color.rgb(110, 231, 183);
    private LinearLayout root;
    private TextView modeValue;
    private String selectedMode = "NORMAL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != Color.TRANSPARENT) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addGap(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private TextView cardTitle(String title) {
        TextView t = text(title, 14, Color.rgb(156, 163, 175), true);
        return t;
    }

    private LinearLayout panel() {
        LinearLayout p = column();
        p.setPadding(dp(16), dp(16), dp(16), dp(16));
        p.setBackground(shape(Color.rgb(24, 29, 37), 18, Color.rgb(47, 55, 68)));
        return p;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(12, 15, 20));
        root = column();
        root.setPadding(dp(18), dp(20), dp(18), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("KuKirin", 15, accent, true);
        root.addView(brand);
        addGap(root, 3);
        TextView heading = text("G4 TUNING", 29, Color.WHITE, true);
        root.addView(heading);
        TextView subtitle = text("Dashboard & setări vizuale", 14, Color.rgb(156, 163, 175), false);
        root.addView(subtitle);
        addGap(root, 22);

        LinearLayout status = panel();
        status.addView(cardTitle("STARE CONEXIUNE"));
        addGap(status, 8);
        status.addView(text("Mod demonstrație • fără conexiune la trotinetă", 14, Color.rgb(253, 186, 116), true));
        addGap(status, 4);
        status.addView(text("Valorile afișate sunt exemple, nu date reale.", 12, Color.rgb(156, 163, 175), false));
        root.addView(status);
        addGap(root, 14);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout speed = metricCard("VITEZĂ", "0", "km/h");
        LinearLayout battery = metricCard("BATERIE", "--", "%");
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, -2, 1);
        mp.setMargins(0, 0, dp(7), 0);
        metrics.addView(speed, mp);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -2, 1);
        bp.setMargins(dp(7), 0, 0, 0);
        metrics.addView(battery, bp);
        root.addView(metrics);
        addGap(root, 14);

        LinearLayout modes = panel();
        modes.addView(cardTitle("PROFIL INTERFAȚĂ"));
        addGap(modes, 10);
        modeValue = text(selectedMode, 22, accent, true);
        modes.addView(modeValue);
        addGap(modes, 10);
        LinearLayout modeButtons = new LinearLayout(this);
        modeButtons.setOrientation(LinearLayout.HORIZONTAL);
        addModeButton(modeButtons, "ECO");
        addModeButton(modeButtons, "NORMAL");
        addModeButton(modeButtons, "SPORT");
        modes.addView(modeButtons);
        addGap(modes, 7);
        modes.addView(text("Aceste butoane schimbă doar eticheta din aplicație.", 12, Color.rgb(156, 163, 175), false));
        root.addView(modes);
        addGap(root, 14);

        LinearLayout settings = panel();
        settings.addView(cardTitle("SETĂRI"));
        addGap(settings, 12);
        Button brightness = button("Comută luminozitatea");
        brightness.setOnClickListener(v -> {
            int current = getWindow().getDecorView().getSystemUiVisibility();
            boolean light = (current & View.SYSTEM_UI_FLAG_LOW_PROFILE) == 0;
            getWindow().getDecorView().setSystemUiVisibility(light ? View.SYSTEM_UI_FLAG_LOW_PROFILE : 0);
            Toast.makeText(this, "Luminozitatea interfeței a fost comutată.", Toast.LENGTH_SHORT).show();
        });
        settings.addView(brightness);
        addGap(settings, 9);
        Button colorButton = button("Schimbă culoarea accentului");
        colorButton.setOnClickListener(v -> {
            accent = accent == Color.rgb(110, 231, 183) ? Color.rgb(96, 165, 250) : Color.rgb(110, 231, 183);
            modeValue.setTextColor(accent);
            Toast.makeText(this, "Accent actualizat.", Toast.LENGTH_SHORT).show();
        });
        settings.addView(colorButton);
        root.addView(settings);
        addGap(root, 18);

        TextView disclaimer = text("Notă: această versiune nu se conectează la controler, motor sau baterie și nu trimite comenzi către KuKirin G4. Pentru date reale ar fi necesar un protocol compatibil și documentat.", 12, Color.rgb(156, 163, 175), false);
        disclaimer.setPadding(dp(2), dp(4), dp(2), dp(4));
        root.addView(disclaimer);
    }

    private LinearLayout metricCard(String label, String value, String unit) {
        LinearLayout p = panel();
        p.addView(cardTitle(label));
        addGap(p, 12);
        p.addView(text(value, 32, Color.WHITE, true));
        p.addView(text(unit, 12, Color.rgb(156, 163, 175), false));
        return p;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(shape(Color.rgb(39, 48, 61), 12, Color.rgb(63, 73, 88)));
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        return b;
    }

    private void addModeButton(LinearLayout row, String label) {
        Button b = button(label);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
        lp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(b, lp);
        b.setOnClickListener(v -> {
            selectedMode = label;
            modeValue.setText(label);
            Toast.makeText(this, "Profil vizual: " + label, Toast.LENGTH_SHORT).show();
        });
    }
}
