# KuKirin G4 Tuning — compilare APK în cloud

Acest proiect este pregătit pentru compilare prin **GitHub Actions**, direct din browserul Android. Nu cere tokenuri, parole sau secrete către servicii terțe.

## Ce conține

- Proiect Android nativ Java, compatibil cu Android 6.0+ (API 23+).
- Workflow: `.github/workflows/build-apk.yml`.
- La fiecare push pe `main`/`master`, la pull request sau la pornire manuală, GitHub compilează APK-ul de test și îl publică drept **Artifact** pentru 14 zile.
- Aplicația este un prototip de interfață. **Nu se conectează la trotineta reală** și nu modifică viteza, motorul, bateria ori controllerul. Viteza și bateria sunt demonstrative.

## Pași de pe telefonul Android

### 1. Creează un repository pe GitHub

1. Deschide Chrome și intră pe https://github.com/new
2. Autentifică-te în contul tău GitHub.
3. La **Repository name**, scrie `KuKirinG4Tuning`.
4. Alege **Public** sau **Private** și apasă **Create repository**.
5. Lasă pagina repository-ului deschisă.

Nu publica parole, tokenuri sau chei API. Acest proiect nu are nevoie de ele.

### 2. Încarcă fișierele ZIP din browser

GitHub nu dezarhivează automat un ZIP încărcat în repository. Mai întâi extrage arhiva în telefon, cu aplicația de fișiere a telefonului sau un arhivator.

1. Descarcă și extrage `KuKirinG4Tuning_CloudBuild.zip`.
2. În repository, apasă **Add file → Upload files**.
3. Selectează fișierele și folderele **din interiorul** arhivei extrase. În rădăcina repository-ului trebuie să apară `app`, `.github`, `build.gradle`, `settings.gradle` și `gradle.properties` — nu doar folderul ZIP.
4. La **Commit changes**, confirmă încărcarea pe ramura `main`.

**Sfat pentru telefon:** dacă interfața mobilă nu arată `Add file` sau nu permite selectarea mai multor foldere, activează din meniul Chrome **⋮ → Desktop site**. Încarcă structura proiectului, nu arhiva ZIP ca un singur fișier.

### 3. Pornește compilarea

1. În repository, deschide fila **Actions**.
2. Dacă GitHub îți cere să activezi Actions, apasă butonul de activare.
3. Deschide workflow-ul **Build Android APK**.
4. La prima încărcare, compilarea pornește automat după commit. Pentru a o porni manual, apasă **Run workflow** dacă opțiunea este disponibilă.
5. Așteaptă până când rularea are bifă verde. Dacă eșuează, deschide rularea și apoi pasul roșu **Build APK** pentru log.

### 4. Descarcă APK-ul compilat

1. Deschide rularea reușită din **Actions**.
2. Derulează la **Artifacts**.
3. Apasă `KuKirinG4Tuning-debug-APK` pentru a descărca arhiva cu APK-ul.
4. Deschide arhiva descărcată și extrage `app-debug.apk`.
5. Apasă fișierul APK și urmează instrucțiunile Android. Este posibil ca Android să ceară permisiunea de a instala aplicații din sursa folosită de browser/managerul de fișiere. Activeaz-o numai dacă ai verificat că APK-ul vine din propriul tău repository și dintr-o rulare GitHub Actions reușită.

## Note importante

- Acesta este un **debug APK**, potrivit pentru testare; nu este un APK de lansare semnat pentru distribuție.
- Artifact-ul expiră după 14 zile; descarcă-l înainte de expirare.
- Nu sunt necesare GitHub Secrets sau tokenuri externe. Autentificarea pe GitHub este necesară doar pentru a-ți administra repository-ul.
- Workflow-ul folosește acțiuni GitHub publice. Înainte să folosești un workflow dintr-un repository necunoscut, verifică-i conținutul.
